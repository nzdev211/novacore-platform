# Tests for contracts
