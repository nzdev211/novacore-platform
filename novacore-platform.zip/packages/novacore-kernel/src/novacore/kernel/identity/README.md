# identity

# Purpose
Provide immutable, type-safe, globally unique identities for every Kernel entity.
Design and implement the best immutable Identifier abstraction we can, because every other Kernel concept will depend on it.
Represents the immutable identity of one Conversation.?
Identity will be incredibly solid
If we get Identity right, the rest of the Kernel will naturally grow on a solid foundation.

# Responsibilities
## Identifier
- Should it be abstract?
- Should it be generic?
- Should it wrap UUID?
- Should it expose value?
- Should it be immutable?
- Should equality compare value?

What is an Identifier?
An Identifier is NOT
- a UUID
- a string
- a database key
- a Firestore document id

Those are implementations.

An Identifier IS A value object that uniquely identifies one domain entity for its entire lifetime.
I deliberately avoided saying UUID.
That means tomorrow we can switch to:
- UUIDv7
- ULID
- Snowflake
- KSUID
- NanoID

without changing the Kernel language.

Identity owns one thing.
- Identity.
- Not generation.
- Not persistence.
- Not storage.
- Just identity.


## ConversationId
- Should it add behavior?
- Or simply inherit Identifier?
- Generation isn't Conversation's Responsibilty
- Never reused
- Never reassigned
- Never generated manually by application code

## ExecutionId
- Should it add behaviour?
- Or simply inherit Identifier
- Generation isn't Execution's Responsibility
- Never reused
- Never reassigned
- Never generated manually by application code

## WorkId
- Should it add behaviour? 
- or simply inherit Identifier
- Generation isn't Execution's Responsibility
- Never reused
- Never reassigned
- Never generated manually by application code

Everything inherits Identifier behaviour

## Immutability
This one is non-negotiable.
Every Identifier must be immutable.
Meaning after creation it can never change. Ever.

## Hashability
required

## Serialization
required, because :
- FastAPI
- Firestore
- Google ADK
- Postgress
All need it, but kernel doesn't know those frameworks
kernel simply guarantees. it can become a string

Public Types

Depends On

Used By

Rules

Future Evolution


## Domain Model
Identifier (abstract)

│

├── ConversationId

├── ExecutionId

├── WorkId

├── WorkerId

├── RequestId

└── TraceId


B001-001 — Identifier Public API Review
Version: 0.1
Status: Draft
Dependency Layer: L0

Purpose
Identifier is the root value object for every domain identity in the Novacore Kernel.

It provides a common semantic contract for immutable, strongly-typed identities while remaining completely independent from infrastructure, persistence, transports, and execution frameworks.

Every domain entity identity in Novacore MUST derive from this abstraction.

Responsibilities
Identifier is responsible for:

Representing one immutable identity.
Providing value-based equality.
Providing a stable string representation.
Providing hashability.
Preventing comparison across different identity types.

Identifier is NOT responsible for:

Generating identifiers.
Database integration.
UUID implementation.
Serialization formats.
Persistence.
Transport concerns.
Public API

The public surface area intentionally remains very small.

class Identifier:
    value: str

Required behavior:

str(identifier)

Returns the canonical string representation.

repr(identifier)

Returns a developer-friendly representation.

identifier == other

Only returns True when:

both identifiers are the same concrete type
both represent the same value
hash(identifier)

Must be stable.

Construction
Construction must validate invariants.

Example:

ConversationId("...")

Valid.

Invalid identifiers must fail immediately.

Immutability
Identifiers are immutable.

After construction:

value never changes
type never changes
equality never changes
Equality Rules

Valid:
ConversationId("abc")

==

ConversationId("abc")

Invalid:

ConversationId("abc")

==

ExecutionId("abc")

Always False.

Type safety is part of the contract.
Hash Rules
Identifiers must be usable as:

dictionary keys
set members

Hash behavior must be consistent with equality.

String Representation

The canonical representation is:

str(identifier)

Applications should not access implementation details.

The identifier is responsible for presenting itself.

Error Handling

Construction fails when:

value is empty
value is whitespace
value is invalid according to the identifier contract

Failure should occur immediately.

Thread Safety

Identifier is immutable.

Therefore:

inherently thread-safe
inherently shareable
no synchronization required
Dependency Rules

Identifier belongs to Layer L0.

Allowed dependencies:

Python Standard Library

Forbidden dependencies:

Runtime
FastAPI
Google ADK
Firestore
PostgreSQL
Pydantic
HTTP
JSON libraries
Logging frameworks
Examples
conversation_id = ConversationId("...")
work_id = WorkId("...")
conversation_id == another_conversation_id

Valid.

conversation_id == work_id

Always False.

Non Goals

Identifier does not implement:

UUID generation
Snowflake IDs
ULID
KSUID
Database keys
Auto increment IDs

Generation strategy belongs outside the Kernel.

Future Evolution

Possible future enhancements include:

Identity generators
UUIDv7 support
ULID support
Snowflake support
Pluggable generation strategies

These are intentionally excluded from Blueprint B001.

Exit Criteria

This API is considered complete when:

every invariant is implemented
all equality rules are tested
immutability is verified
hash behavior is verified
examples compile
public API is frozen

After approval, no breaking changes are permitted without an NCR (Novacore Change Request).