# Specification for identity


## Invariants
- Document the conditions that must always hold true for this module.
- Define constraints that cannot be violated.
- Never empty
- Never mutable
- Globally unique
- Serializable
- Comparable
- Hashable

## State Machine
- Describe the lifecycle states of this module.
- Show valid transitions between states.

## Dependency Rules
- List which modules this one depends on.
- Define allowed and forbidden dependency directions.

## Public API
- Enumerate the exposed functions, classes, or interfaces.
- Clarify usage contracts and expected inputs/outputs.

Blueprint B001 — Identity Foundation

Mission
Provide immutable, type-safe, globally unique identities for every Kernel entity.

The Identity Foundation is the first implementation milestone of Novacore Kernel. Every higher dependency layer depends on it, therefore this foundation must remain extremely small, dependency-free, and stable.

Objectives
Define the identity language of Novacore.
Provide immutable value objects representing entity identities.
Establish a stable public API that will be reused throughout the platform.
Remain completely independent from Runtime, transports, adapters, and infrastructure.
Scope
Included
Identifier
ConversationId
ExecutionId
WorkId
WorkerId
RequestId
TraceId
Explicitly Excluded
Runtime
Google ADK
FastAPI
Firestore
PostgreSQL
Identity providers
UUID generation strategies
Persistence
Serialization frameworks

These concerns belong to higher layers and must not influence the Kernel.

Domain Model
Identifier (abstract value object)

├── ConversationId
├── ExecutionId
├── WorkId
├── WorkerId
├── RequestId
└── TraceId

Each identifier represents exactly one domain entity and exists only to model identity.

Definition

An Identifier is an immutable value object that uniquely identifies one domain entity throughout its lifetime.

An Identifier is not:

a database primary key
a Firestore document ID
a UUID implementation
a transport identifier
an infrastructure concern

Those are implementation details.

Identity is a domain concept.

Public Types
Identifier
Base abstraction for all domain identities.

ConversationId
Represents the identity of one Conversation.

ExecutionId
Represents the identity of one Execution.

WorkId
Represents the identity of one Work.

WorkerId
Represents the identity of one Worker.

RequestId
Represents the identity of one incoming request.

TraceId
Represents one distributed execution trace.

Invariants
Every Identifier must satisfy the following rules.

Identity
Represents exactly one entity.
Cannot represent multiple entities.

Immutability
Cannot be modified after creation.
No mutable state.

Equality
Equal only to identifiers of the same type.
Underlying value alone is not sufficient for equality.

Example:
ConversationId("abc") ≠ WorkId("abc")

Hashability
Identifiers must be hashable.
They must be usable as dictionary keys and set members.

Comparability
Identifiers must support equality comparison with identifiers of the same type.
Ordering is not required.

Serialization
Identifiers must expose a stable string representation.
The Kernel guarantees string conversion only.
Transport-specific serialization belongs outside the Kernel.

Stability
Once created,
an Identifier never changes.

Dependency Layer
Layer: L0

Allowed dependencies:
Python Standard Library

Forbidden dependencies:
Runtime
FastAPI
Google ADK
Firestore
PostgreSQL
Pydantic
External infrastructure

Identity is the root of the dependency graph.

Public API Principles
The public API should feel natural to Python developers.

Desired usage:
from novacore.kernel.identity import (
    Identifier,
    ConversationId,
    ExecutionId,
    WorkId,
    WorkerId,
    RequestId,
    TraceId,
)

Applications should never need to import internal implementation modules.

Examples
conversation_id = ConversationId(...)
execution_id = ExecutionId(...)
work_id = WorkId(...)

conversation_id == another_conversation_id
Valid.

conversation_id == work_id
Must always evaluate to False.

Testing Strategy
Implementation is complete only when the following behaviors are verified.

Identifier is immutable.
Identifier is hashable.
Identifier equality behaves correctly.
Different identifier types are never equal.
String representation is stable.
Invalid construction is rejected.
Public API matches the specification.
Exit Criteria

Blueprint B001 is complete only when all of the following are satisfied.

Identity language is finalized.
Public API is frozen.
Invariants are documented.
Unit tests verify every invariant.
Example usage is documented.
Dependency layer rules are enforced.
No infrastructure dependencies exist.

Only after these conditions are met may the project proceed to Blueprint B002 — Capability Foundation.

Architectural Principles
Identity is a domain concept.
Identity owns only identity.
Identity does not own persistence.
Identity does not own generation strategies.
Identity does not own infrastructure.
Identity is the foundation of the Novacore Kernel.
Every higher dependency layer builds upon Identity.

